<?php
// Koneksi ke database
require "connect.php"
// Ambil nomor BP dari permintaan POST
$nobp = $_POST['nobp'];

// Query untuk mendapatkan nama dari database
$query = "SELECT nama FROM tabel_pengguna WHERE nobp = '$nobp'";

// Eksekusi query
$result = mysqli_query($conn, $query);

// Cek hasil query
if (mysqli_num_rows($result) > 0) {
    // Ambil baris pertama dari hasil query
    $row = mysqli_fetch_assoc($result);
    
    // Buat respons dengan data nama
    $response = [
        'nama' => $row['nama']
    ];
    
    // Mengembalikan data dalam format JSON
    echo json_encode($response);
} else {
    // Jika data tidak ditemukan, kirim respons dengan pesan error
    $response = [
        'error' => 'Data tidak ditemukan'
    ];
    
    echo json_encode($response);
}

?>
